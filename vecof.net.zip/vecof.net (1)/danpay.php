
<!DOCTYPE html>

<html lang="ru" data-textdirection="ltr" class="loaded"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="referrer" content="no-referrer">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="http://svuti.ml/files/fav_logo.ico" />
    <title>Svuti ошибка платежа</title>
    <link rel="apple-touch-icon" href="">
    <link rel="shortcut icon" type="image/x-icon" href="">
    <link href="files/css" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="files/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="files/style.min.css">
    <link rel="stylesheet" type="text/css" href="files/font-awesome.min.css">

    <!-- END VENDOR CSS-->
    <!-- BEGIN STACK CSS-->
    <link rel="stylesheet" type="text/css" href="files/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="files/app.min.css">
    <link rel="stylesheet" type="text/css" href="files/colors.min.css">

    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="files/style.css">
    <script>
	setTimeout("document.location.href='http://svuti.ml'", 1300);
	</script>
  </head>
  <body data-open="click" data-menu="horizontal-menu" data-col="2-columns" class="horizontal-layout horizontal-menu 2-columns    menu-expanded " cz-shortcut-listen="true">

 



    <div class="app-content container center-layout" style="padding-right:0px!important;">
      <div class="content-wrapper" >
       
        <div class="content-body"><!--native-font-stack -->





<section id="description-list-alignment">


<div class="row">
    <!-- Description lists horizontal -->
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h1 style='font-size:35px'class="card-title danger text-xs-center"><b>Ошибка платежа!</b></h1>
            </div>
            <div class="card-body collapse in">
                <div class="card-block">
                    <div class="card-text text-xs-center">
<img  src="files/security.png" width="410px"/>                    

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Description lists horizontal-->
</div>
</section>
        </div>
      </div>
    </div>
</body></html>